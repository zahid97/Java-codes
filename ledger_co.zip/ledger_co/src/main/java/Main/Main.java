package Main;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import util.HelperFunctions;

public class Main {

	public static void main(String[] args) {
		Map<String, String[]> loanInputMap = new LinkedHashMap<>();
		Map<String, String[]> paymentInputMap = new LinkedHashMap<>();
		List<String[]> balanceInputList = new ArrayList<>();
		String filePath = new File("").getAbsolutePath();
		filePath = filePath.concat("\\src\\main\\resources\\resources\\abc.txt");
		List<String> data = readFileAsString(filePath);
		int noOfInputs = data.size();

		for (int i = 0; i < noOfInputs; i++) {
			String input = data.get(i);
			String[] splitInput = input.split(" ");
			String typeOfInput = splitInput[0];
			String bankName = splitInput[1].toLowerCase();
			String borrowerName = splitInput[2].toLowerCase();
			if (typeOfInput.equalsIgnoreCase("loan")) {
				loanInputMap.put(bankName + "_" + borrowerName, splitInput);
			} else if (typeOfInput.equalsIgnoreCase("payment")) {
				paymentInputMap.put(bankName + "_" + borrowerName, splitInput);
			} else {
				balanceInputList.add(splitInput);
			}
		}

		try {
			HelperFunctions helper = new HelperFunctions();
			helper.startProcessing(balanceInputList, paymentInputMap, loanInputMap);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Exception occured " + e);

		}

	}

	private static List<String> readFileAsString(String fileName) {
		// TODO Auto-generated method stub
		List<String> data = new ArrayList<>();
		BufferedReader br = null;
		try {
			br = new BufferedReader(new FileReader(fileName));
			String line;
			while ((((line = br.readLine()) != null) && !("".equals(line)))) {
				data.add(line);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return data;
	}

}
