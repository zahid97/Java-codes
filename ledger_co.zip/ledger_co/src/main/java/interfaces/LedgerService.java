package interfaces;

import model.PaymentInformation;

public interface LedgerService {

	public void loanAmount(PaymentInformation paymentInformation);

	public void balanceAmount(int noOfEmi, String type, PaymentInformation paymentInformation);

	public void paymentAmount(Double lumSumAmount, Integer afterEmi, String bankName, PaymentInformation paymentInformation);

}
