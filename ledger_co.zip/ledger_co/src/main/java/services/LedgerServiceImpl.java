package services;

import model.EmiPaymentInformation;
import model.LoanInformation;
import model.LumSumPaymentInformation;
import model.PaymentInformation;
import model.Type;

import interfaces.LedgerService;

public class LedgerServiceImpl implements LedgerService {
	int totalEmi = 0;
	int totalAmountPaid = 0;

	@Override
	public void loanAmount(PaymentInformation paymentInformation) {
		// TODO Auto-generated method stub
		int perEmiAmount = Integer.MIN_VALUE;
		int totalAmoutToBePaid = 0;
		LoanInformation loanInformatioin = paymentInformation.getLoanInformation();
		paymentInformation.setEmiPaymentInformation(new EmiPaymentInformation());
		EmiPaymentInformation emiPaymentInformation = paymentInformation.getEmiPaymentInformation();
		int interest = (int) Math.ceil(loanInformatioin.getPrincipalAmount() * loanInformatioin.getNoOfYears()
				* (loanInformatioin.getRateOfInterest() / 100));
		Double noOfYears = loanInformatioin.getNoOfYears();
		totalAmoutToBePaid = (int) Math.ceil(interest + loanInformatioin.getPrincipalAmount());
		perEmiAmount = (int) Math.ceil(totalAmoutToBePaid / (noOfYears * 12));
		emiPaymentInformation.setPerEmiAmount(perEmiAmount);
		emiPaymentInformation.setTotalAmoutToBePaid(totalAmoutToBePaid);
		paymentInformation.setEmiPaymentInformation(emiPaymentInformation);

	}

	@Override
	public void balanceAmount(int noOfEmi, String type, PaymentInformation paymentInformation) {
		// TODO Auto-generated method stub
		LoanInformation loanInformation = paymentInformation.getLoanInformation();
		LumSumPaymentInformation paymentAmount = paymentInformation.getLumSumPaymentInformation();
		EmiPaymentInformation emiPaymentInformation = paymentInformation.getEmiPaymentInformation();
		if (type.equalsIgnoreCase(Type.BALANCE.toString())) {
			totalEmi = (int) Math.ceil((loanInformation.getNoOfYears()) * 12);
			emiPaymentInformation.setTotalEmi(totalEmi);
			totalAmountPaid = (noOfEmi * emiPaymentInformation.getPerEmiAmount());
			System.out.println(loanInformation.getBankName() + " " + loanInformation.getBorrowersName() + " " + " "
					+ totalAmountPaid + " " + (emiPaymentInformation.getTotalEmi() - noOfEmi));
			return;
		} else {
			int currentEmi = noOfEmi - paymentAmount.getAfterEmi();
			if (currentEmi < paymentAmount.getEmiLeft()) {
				totalAmountPaid = paymentAmount.getTotalAmount()
						+ (currentEmi * emiPaymentInformation.getPerEmiAmount());
				paymentAmount.setTotalAmount(totalAmountPaid);
				System.out.println(loanInformation.getBankName() + " " + loanInformation.getBorrowersName() + " " + " "
						+ paymentAmount.getTotalAmount() + " " + (paymentAmount.getEmiLeft() - currentEmi));
			}

		}

	}

	@Override
	public void paymentAmount(Double lumSumAmount, Integer afterEmi, String bankName,
			PaymentInformation paymentInformation) {
		// TODO Auto-generated method stub
		paymentInformation.setLumSumPaymentInformation(new LumSumPaymentInformation());
		LumSumPaymentInformation paymentAmount = paymentInformation.getLumSumPaymentInformation();
		EmiPaymentInformation emiPaymentInformation = paymentInformation.getEmiPaymentInformation();
		paymentAmount.setBankName(bankName);
		paymentAmount.setAfterEmi(afterEmi + 1);
		int totalAmountPaidBeforeLumSum = emiPaymentInformation.getPerEmiAmount() * (afterEmi + 1);
		totalAmountPaid = (int) ((int) totalAmountPaidBeforeLumSum + Math.ceil(lumSumAmount));
		paymentAmount.setTotalAmount(totalAmountPaid);
		totalEmi = (int) Math
				.ceil(((double) emiPaymentInformation.getTotalAmoutToBePaid() - (double) paymentAmount.getTotalAmount())
						/ emiPaymentInformation.getPerEmiAmount());
		paymentAmount.setEmiLeft(totalEmi);

	}

}
