package model;

public enum Type {
	 LOAN,
	BALANCE,
	PAYMENT
	
}
