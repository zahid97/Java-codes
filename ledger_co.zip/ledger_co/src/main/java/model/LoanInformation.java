package model;

public class LoanInformation {
	private String bankName;
	private String borrowersName;
	private Double principalAmount;
	private Double noOfYears;
	private Double rateOfInterest;

	public LoanInformation() {
		super();
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBorrowersName() {
		return borrowersName;
	}

	public void setBorrowersName(String borrowersName) {
		this.borrowersName = borrowersName;
	}

	public Double getPrincipalAmount() {
		return principalAmount;
	}

	public void setPrincipalAmount(Double principalAmount) {
		this.principalAmount = principalAmount;
	}

	public Double getNoOfYears() {
		return noOfYears;
	}

	public void setNoOfYears(Double noOfYears) {
		this.noOfYears = noOfYears;
	}

	public Double getRateOfInterest() {
		return rateOfInterest;
	}

	public void setRateOfInterest(Double rateOfInterest) {
		this.rateOfInterest = rateOfInterest;
	}

	@Override
	public String toString() {
		return "LendingInformation [bankName=" + bankName + ", borrowersName=" + borrowersName + ", principalAmount="
				+ principalAmount + ", noOfYears=" + noOfYears + ", rateOfInterest=" + rateOfInterest + "]";
	}

}
