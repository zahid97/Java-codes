package model;

public class LumSumPaymentInformation {
	private String bankName;
	private int emiLeft;
	private int totalAmount;
	private int afterEmi;

	public LumSumPaymentInformation() {
		super();
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public int getEmiLeft() {
		return emiLeft;
	}

	public void setEmiLeft(int afterEmi) {
		this.emiLeft = afterEmi;
	}

	public int getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(int totalAmountPaid) {
		this.totalAmount = totalAmountPaid;
	}

	public int getAfterEmi() {
		return afterEmi;
	}

	public void setAfterEmi(int afterEmi) {
		this.afterEmi = afterEmi;
	}

}
