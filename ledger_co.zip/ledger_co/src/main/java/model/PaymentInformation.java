package model;

public class PaymentInformation {
	
	private EmiPaymentInformation emiPaymentInformation;
	private LoanInformation loanInformation;
	private LumSumPaymentInformation lumSumPaymentInformation;
	
	public EmiPaymentInformation getEmiPaymentInformation() {
		return emiPaymentInformation;
	}
	public void setEmiPaymentInformation(EmiPaymentInformation emiPaymentInformation) {
		this.emiPaymentInformation = emiPaymentInformation;
	}
	public LoanInformation getLoanInformation() {
		return loanInformation;
	}
	public void setLoanInformation(LoanInformation loanInformation) {
		this.loanInformation = loanInformation;
	}
	public LumSumPaymentInformation getLumSumPaymentInformation() {
		return lumSumPaymentInformation;
	}
	public void setLumSumPaymentInformation(LumSumPaymentInformation lumSumPaymentInformation) {
		this.lumSumPaymentInformation = lumSumPaymentInformation;
	}
	
	
	

}
