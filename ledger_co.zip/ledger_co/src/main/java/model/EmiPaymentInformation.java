package model;

public class EmiPaymentInformation {
	private int perEmiAmount = Integer.MIN_VALUE;
	private int totalEmi = 0;
	private int totalAmoutToBePaid = 0;

	public int getPerEmiAmount() {
		return perEmiAmount;
	}

	public void setPerEmiAmount(int perEmiAmount) {
		this.perEmiAmount = perEmiAmount;
	}

	public int getTotalEmi() {
		return totalEmi;
	}

	public void setTotalEmi(int totalEmi) {
		this.totalEmi = totalEmi;
	}

	public int getTotalAmoutToBePaid() {
		return totalAmoutToBePaid;
	}

	public void setTotalAmoutToBePaid(int totalAmoutToBePaid) {
		this.totalAmoutToBePaid = totalAmoutToBePaid;
	}

}
