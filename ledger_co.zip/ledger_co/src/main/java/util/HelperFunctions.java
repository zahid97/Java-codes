package util;

import java.util.List;
import java.util.Map;

import model.LoanInformation;
import model.PaymentInformation;
import model.Type;
import services.LedgerServiceImpl;

import interfaces.LedgerService;

public class HelperFunctions {
	
	public void startProcessing(List<String[]> balanceInputList, Map<String, String[]> paymentInputMap,
			Map<String, String[]> loanInputMap) {
		
		LedgerService ledgerService = new LedgerServiceImpl();
		//LumSumPaymentInformation paymentAmount = new LumSumPaymentInformation();
		PaymentInformation paymentInformation = new PaymentInformation();
		// TODO Auto-generated method stub
		for (String[] eachInput : balanceInputList) {
			String key = eachInput[1].toLowerCase() + "_" + eachInput[2].toLowerCase();
			String[] values = loanInputMap.get(key);
			setVariables(values, ledgerService, paymentInformation);
			int balanceEmi = Integer.valueOf(eachInput[3]);
			if (paymentInputMap.containsKey(key)) {
				String[] paymentValues = paymentInputMap.get(key);
				int paymentEmi = Integer.valueOf(paymentValues[4]);
				Double lumSumAmount = Double.valueOf(paymentValues[3]);
				if (balanceEmi >= paymentEmi) {
					ledgerService.paymentAmount(lumSumAmount, paymentEmi, paymentValues[1], paymentInformation);
					ledgerService.balanceAmount(balanceEmi, Type.PAYMENT.toString(), paymentInformation);
				} else {
					ledgerService.balanceAmount(balanceEmi, Type.BALANCE.toString(), paymentInformation);
				}
			} else {
				ledgerService.balanceAmount(balanceEmi, Type.BALANCE.toString(), paymentInformation);
			}

		}

	}
	
	private void setVariables(String[] input, LedgerService ledgerService, PaymentInformation paymentInformation) {
		if (input[0].equalsIgnoreCase(Type.LOAN.toString())) {
			String bankName = input[1];
			String borrowersName = input[2];
			Double principalAmount = Double.valueOf(input[3]);
			Double noOfYears = Double.valueOf(input[4]);
			Double rateOfInterest = Double.valueOf(input[5]);
			LoanInformation li = new LoanInformation();
			li.setBankName(bankName);
			li.setBorrowersName(borrowersName);
			li.setPrincipalAmount(principalAmount);
			li.setNoOfYears(noOfYears);
			li.setRateOfInterest(rateOfInterest);
			paymentInformation.setLoanInformation(li);
			ledgerService.loanAmount(paymentInformation);
			
		}
	}

}
