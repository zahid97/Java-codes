package services;

import interfaces.LedgerService;
import model.EmiPaymentInformation;
import model.LoanInformation;
import model.LumSumPaymentInformation;
import model.PaymentInformation;
import model.Type;

import junit.framework.Assert;

public class LedgerServiceImplTest {
	
	private LedgerService ls = new LedgerServiceImpl();
	
	@org.junit.Test
	public void paymentInfoBalanaceEmiTest() {
		PaymentInformation p = new PaymentInformation();
		LoanInformation loanInformation = new LoanInformation();
		EmiPaymentInformation emiPaymentInformation = new EmiPaymentInformation();
		loanInformation.setNoOfYears(5d);
		loanInformation.setBankName("IDIDI");
		loanInformation.setBorrowersName("DALE");
		loanInformation.setPrincipalAmount(10000d);
		loanInformation.setRateOfInterest(4d);
		emiPaymentInformation.setPerEmiAmount(200);
		emiPaymentInformation.setTotalAmoutToBePaid(12000);
		p.setLoanInformation(loanInformation);
		p.setEmiPaymentInformation(emiPaymentInformation);
		
		ls.balanceAmount(5, Type.BALANCE.toString(), p);
		Assert.assertEquals("Actual EMI = Expected EMI", 55,emiPaymentInformation.getTotalEmi() - 5);
		//fail("Not yet implemented");
	}
	
	@org.junit.Test
	public void paymentInfoEmiTest() {
		PaymentInformation p = new PaymentInformation();
		LoanInformation loanInformation = new LoanInformation();
		EmiPaymentInformation emiPaymentInformation = new EmiPaymentInformation();
		loanInformation.setNoOfYears(3d);
		loanInformation.setBankName("MBI");
		loanInformation.setBorrowersName("HArry");
		loanInformation.setPrincipalAmount(10000d);
		loanInformation.setRateOfInterest(7d);
		emiPaymentInformation.setPerEmiAmount(337);
		emiPaymentInformation.setTotalAmoutToBePaid(12100);
		p.setLoanInformation(loanInformation);
		p.setEmiPaymentInformation(emiPaymentInformation);
		ls.paymentAmount(5000d, 10, "MBI", p);
		ls.balanceAmount(12, Type.PAYMENT.toString(), p);
		Assert.assertEquals("Actual EMI = Expected EMI", 10,p.getLumSumPaymentInformation().getEmiLeft() - 1);
		//fail("Not yet implemented");
	}
	
	
	@org.junit.Test
	public void paymentInfoBalanaceAmountTest() {
		PaymentInformation p = new PaymentInformation();
		LoanInformation loanInformation = new LoanInformation();
		EmiPaymentInformation emiPaymentInformation = new EmiPaymentInformation();
		loanInformation.setNoOfYears(5d);
		loanInformation.setBankName("IDIDI");
		loanInformation.setBorrowersName("DALE");
		loanInformation.setPrincipalAmount(10000d);
		loanInformation.setRateOfInterest(4d);
		emiPaymentInformation.setPerEmiAmount(200);
		emiPaymentInformation.setTotalAmoutToBePaid(12000);
		p.setLoanInformation(loanInformation);
		p.setEmiPaymentInformation(emiPaymentInformation);
		
		ls.balanceAmount(5, Type.BALANCE.toString(), p);
		Assert.assertEquals("Actual AMOUNT = Expected AMOUNT", 1000,5 * emiPaymentInformation.getPerEmiAmount());
		//fail("Not yet implemented");
	}
	
	@org.junit.Test
	public void paymentInfoAmountTest() {
		PaymentInformation p = new PaymentInformation();
		LoanInformation loanInformation = new LoanInformation();
		EmiPaymentInformation emiPaymentInformation = new EmiPaymentInformation();
		loanInformation.setNoOfYears(3d);
		loanInformation.setBankName("MBI");
		loanInformation.setBorrowersName("HArry");
		loanInformation.setPrincipalAmount(10000d);
		loanInformation.setRateOfInterest(7d);
		emiPaymentInformation.setPerEmiAmount(337);
		emiPaymentInformation.setTotalAmoutToBePaid(12100);
		p.setLoanInformation(loanInformation);
		p.setEmiPaymentInformation(emiPaymentInformation);
		ls.paymentAmount(5000d, 10, "MBI", p);
		ls.balanceAmount(12, Type.PAYMENT.toString(), p);
		Assert.assertEquals("Actual Amount = Expected Amount", 9044,p.getLumSumPaymentInformation().getTotalAmount());
		//fail("Not yet implemented");
	}
	

}
